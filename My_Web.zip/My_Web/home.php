<?php 

	// connect to database
	$db = mysqli_connect('localhost', 'root', '', 'mywebsite');?>
<!DOCTYPE html>
<html>
<head>
<title> Home page</title>
    <link rel="stylesheet" type="text/css" href="style1.css">
</head>
   <body style="background: #128184 ">
       <div class="headerhome">
		<h2>suolmeiat</h2>
	</div>

   <form method="post" class="stylehome" action="home.php">

   	<nav class="navbar navbar-expand-lg navbar-light bg-light">
  
 <a class="navbar-brand" href="#">
    <img src="Z.jpg" width="70" height="50" class="d-inline-block align-top" alt="" loading="lazy"><font color="FF##FF">
    suolmaeit</font></a>

   <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div style="justify-content:right ;" class="collapse navbar-collapse" id="navbarNav">
    <ul class="navbar-nav">
      <li class="nav-item active">
        <a class="nav-link" href="page7.php"><font color="red">CALL TO AS </font><span class="sr-only">(current)</span></a>
      </li>
 </ul>
</div>
 <button style="justify-content: right;" type="button" class="btn btn-danger">
 <div style="justify-content: right;" class="collapse navbar-collapse" id="navbarNav">
    <ul class="navbar-nav">
      <li class="nav-item">
        <a class="nav-link" href="login.php"><font color="##yyff">
        SING OUT
      </button></font></a>
      </li>
    </ul>
  </div>
</nav>
  <div class="btn btn-default" role="group" aria-label="50"><a href="page4.php">  <b>Kareem</div></a></b>
  <div class="btn btn-default" role="group" aria-label="70"><a href="page3.php"><b>Glycerin</div></a></b>
    <div class="btn btn-default" role="group" aria-label="70"> <a href="page.php"> <b>Mekeup </div></a></b>
      <div class="btn btn-default" role="group" aria-label="70"> <a href="page2.php">  <b>Vaselin</div></a></b>
        <div class="btn btn-default" role="group" aria-label="70"><a href="page1.php">Skin care</div></b></a>
      <br>
      <br>
<b><h1><font color="RED">BAD GUY WELCMAS TO YOU !</h1></font></b>
<b><h2><font color="FF##FF">Here on our site you will find all of the </font></h2></b>
  <b><h3><h2><img src="c2.jpg" /><font color="fbbf"> Kareems
</font></h3></b>
    <b><h3><h2><img src="g.jpg" /><font color="ff##ffrr"> GLersin</font></b>
<h3><b><h2><img src="v0.jpg" /><font color="##ff##"> vazlin</font></b>
<h3><b><h2><img src="m1.jpg" /><font color="ff33qq"> Makeup</font></b>
<h3><b><h2><img src="s1.jpg" /><font color="##33ff"> Skin care</font></h3></b>
<br><br>
      

</form>
</body>
</html>